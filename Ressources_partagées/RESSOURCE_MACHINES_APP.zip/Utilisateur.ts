export type IQuota = {
  idCompte: number
  quotaBlock: number
  quotaSouple: number
  quotaHard: number
}

export class Utilisateur {
  private idCompte = 0
  private nomUtilisateur: string
  private estValide = false
  private quotaMaxGo = 0
  private espaceUtiliseGo = 0
  private motDePasseHash = ""

  private infoQuota: IQuota = {
    idCompte: this.idCompte,
    quotaBlock: 2000000,
    quotaSouple: 2100000,
    quotaHard: 2200000,
  }

  constructor(nomUtilisateur: string) {
    this.nomUtilisateur = nomUtilisateur
    // this.motDePasseHash = motDepasseHash;
  }

  //Les Setters
  public setIdCompte = (id: number): void => {
    this.idCompte = id
  }
  public setNomUtilisateur = (nom: string): void => {
    this.nomUtilisateur = nom
  }
  public setEstValidite = (estValide: boolean): void => {
    this.estValide = estValide
  }
  public setQuotaMaxGo = (nouveauQuota: number): void => {
    this.quotaMaxGo = nouveauQuota
    this.infoQuota.quotaBlock = nouveauQuota
  }

  public setMotDepasseHash = (motDePasseHash: string): void => {
    this.motDePasseHash = motDePasseHash
  }
  public setEspaceUtilisee = (espaceUtiliseGo: number): void => {
    this.espaceUtiliseGo = espaceUtiliseGo
  }
  public setInfoQuota = (infoQuota: IQuota): void => {
    this.infoQuota = infoQuota
  }

  //Les Getters
  public getIdCompte = (): number => this.idCompte
  public getNomUtilisateur = (): string => this.nomUtilisateur
  public getEstValide = (): boolean => this.estValide
  public getQuotaMaxGo = (): number => this.quotaMaxGo
  public getEspaceUtiliseGo = (): number => this.espaceUtiliseGo
  public getInfoQuota = (): IQuota => this.infoQuota
  public getMotDePasseHash = (): string => this.motDePasseHash

  //Methodes statiques
  static getTousUtilisateurs = (): Utilisateur[] => {
    // Import des comptes système NIS/NFS
    const { comptesSystemeFictifs } = require("./data/mock-data")
    return comptesSystemeFictifs || []
  }

  static getQuotasUtilisateurs = (): { utilisateurs: Utilisateur[]; quotas: IQuota[] } => {
    const utilisateurs: Utilisateur[] = this.getTousUtilisateurs()
    const quotas: IQuota[] = utilisateurs.map((u: Utilisateur) => {
      return u.getInfoQuota()
    })
    return {
      utilisateurs,
      quotas,
    }
  }

  //Methodes classiques
  public verifierIdentifiant = (nom: string, mdp: string): boolean => {
    const utilisateurs: Utilisateur[] = Utilisateur.getTousUtilisateurs()
    const index: number = utilisateurs.findIndex((u) => u.nomUtilisateur === nom && u.motDePasseHash === mdp)
    return index !== -1 ? true : false
  }

  public getEspaceRestant = (): number => {
    const rest = this.infoQuota.quotaBlock - this.espaceUtiliseGo
    return rest
  }
}
