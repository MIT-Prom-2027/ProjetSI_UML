export enum TypeNotification {
  INFO = "INFO",
  SUCCES = "SUCCES",
  AVERTISSEMENT = "AVERTISSEMENT",
  ERREUR = "ERREUR",
}
