"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Users, HardDrive, FileText, Settings, Bell, CheckCircle, XCircle, AlertTriangle, Info } from "lucide-react"

import { Serveur } from "../serveur"
import type { Utilisateur } from "../Utilisateur"
import type { Administrateur } from "../Administrateur"
import type { Application } from "../Application"
import type { DemandeQuota } from "../DemandeQuota"
import type { DemandeInstallation } from "../DemandeInstallation"
import type { Session } from "../Session"
import { type Notification, TypeNotification } from "../Notification"
import {
  comptesSystemeFictifs,
  administrateursWebFictifs,
  utilisateursWebFictifs,
  applicationsFictives,
  demandesQuotaFictives,
  demandesInstallationFictives,
  sessionsFictives,
  notificationsFictives,
} from "../data/mock-data"
import type { UtilisateurStandard } from "../UtilisateurStandard"

export default function SystemManagement() {
  const [serveur] = useState(new Serveur("192.168.1.1"))
  const [utilisateursSysteme] = useState<Utilisateur[]>(comptesSystemeFictifs) // Comptes NIS/NFS
  const [administrateursWeb] = useState<Administrateur[]>(administrateursWebFictifs) // Admins web
  const [utilisateursWeb] = useState<UtilisateurStandard[]>(utilisateursWebFictifs) // Clients web
  const [applications] = useState<Application[]>(applicationsFictives)
  const [demandesQuota, setDemandesQuota] = useState<DemandeQuota[]>(demandesQuotaFictives)
  const [demandesInstallation, setDemandesInstallation] = useState<DemandeInstallation[]>(demandesInstallationFictives)
  const [sessions] = useState<Session[]>(sessionsFictives)
  const [notifications] = useState<Notification[]>(notificationsFictives)

  const formatBytes = (bytes: number) => {
    return (bytes / 1000000).toFixed(2) + " GB"
  }

  const getNotificationIcon = (type: TypeNotification) => {
    switch (type) {
      case TypeNotification.SUCCES:
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case TypeNotification.ERREUR:
        return <XCircle className="h-4 w-4 text-red-500" />
      case TypeNotification.AVERTISSEMENT:
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      default:
        return <Info className="h-4 w-4 text-blue-500" />
    }
  }

  const traiterDemandeQuota = (demande: DemandeQuota, approuve: boolean) => {
    serveur.traiterDemandeQuotaServeur(demande, approuve)
    setDemandesQuota((prev) => prev.filter((d) => d !== demande))
  }

  const traiterDemandeInstallation = (demande: DemandeInstallation, approuve: boolean) => {
    serveur.traiterDemandeInstallationServeur(demande, approuve)
    setDemandesInstallation((prev) => prev.filter((d) => d !== demande))
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Système de Gestion</h1>
          <p className="text-gray-600 mt-2">Serveur: {serveur.getAdresseIp()}</p>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Utilisateurs
            </TabsTrigger>
            <TabsTrigger value="quotas" className="flex items-center gap-2">
              <HardDrive className="h-4 w-4" />
              Quotas
            </TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Applications
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Demandes
            </TabsTrigger>
            <TabsTrigger value="sessions" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Sessions
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Comptes Système NIS/NFS</CardTitle>
                  <CardDescription>Comptes Unix du serveur</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {utilisateursSysteme.map((user) => (
                      <Card key={user.getIdCompte()}>
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            {user.getNomUtilisateur()}
                            <Badge variant={user.getEstValide() ? "default" : "destructive"}>
                              {user.getEstValide() ? "Actif" : "Inactif"}
                            </Badge>
                          </CardTitle>
                          <CardDescription>UID: {user.getIdCompte()}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>Espace utilisé</span>
                                <span>
                                  {formatBytes(user.getEspaceUtiliseGo())} / {formatBytes(user.getQuotaMaxGo())}
                                </span>
                              </div>
                              <Progress
                                value={(user.getEspaceUtiliseGo() / user.getQuotaMaxGo()) * 100}
                                className="h-2"
                              />
                            </div>
                            <div className="text-sm text-gray-600">
                              <p>Espace restant: {formatBytes(user.getEspaceRestant())}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Utilisateurs Web</CardTitle>
                  <CardDescription>Clients connectés au site web</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {utilisateursWeb.map((user) => (
                      <Card key={user.getIPersonne()}>
                        <CardHeader>
                          <CardTitle>
                            {user.getNom()} {user.getPrenom()}
                          </CardTitle>
                          <CardDescription>{user.getEmail()}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <p className="text-sm text-gray-600">
                              Compte système: {user.getCompteSysteme().getNomUtilisateur()}
                            </p>
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>Quota système</span>
                                <span>
                                  {formatBytes(user.getCompteSysteme().getEspaceUtiliseGo())} /{" "}
                                  {formatBytes(user.getCompteSysteme().getQuotaMaxGo())}
                                </span>
                              </div>
                              <Progress
                                value={
                                  (user.getCompteSysteme().getEspaceUtiliseGo() /
                                    user.getCompteSysteme().getQuotaMaxGo()) *
                                  100
                                }
                                className="h-2"
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Administrateurs Web</CardTitle>
                  <CardDescription>Administrateurs du site web</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {administrateursWeb.map((admin) => (
                      <Card key={admin.getIPersonne()}>
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            {admin.getNom()} {admin.getPrenom()}
                            <Badge variant="secondary">Admin</Badge>
                          </CardTitle>
                          <CardDescription>{admin.getEmail()}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <p className="text-sm text-gray-600">
                              Compte système: {admin.getCompteSysteme().getNomUtilisateur()}
                            </p>
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span>Quota système</span>
                                <span>
                                  {formatBytes(admin.getCompteSysteme().getEspaceUtiliseGo())} /{" "}
                                  {formatBytes(admin.getCompteSysteme().getQuotaMaxGo())}
                                </span>
                              </div>
                              <Progress
                                value={
                                  (admin.getCompteSysteme().getEspaceUtiliseGo() /
                                    admin.getCompteSysteme().getQuotaMaxGo()) *
                                  100
                                }
                                className="h-2"
                              />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="quotas">
            <Card>
              <CardHeader>
                <CardTitle>Gestion des Quotas NIS/NFS</CardTitle>
                <CardDescription>Vue d'ensemble des quotas des comptes système Unix</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {utilisateursSysteme.map((user) => {
                    const quotaInfo = user.getInfoQuota()
                    return (
                      <div key={user.getIdCompte()} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{user.getNomUtilisateur()}</h3>
                          <p className="text-sm text-gray-600">UID: {user.getIdCompte()}</p>
                          <p className="text-sm text-gray-600">
                            Utilisé: {formatBytes(user.getEspaceUtiliseGo())} / {formatBytes(quotaInfo.quotaBlock)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm">Quota souple: {formatBytes(quotaInfo.quotaSouple)}</p>
                          <p className="text-sm">Quota dur: {formatBytes(quotaInfo.quotaHard)}</p>
                          <Badge variant={user.getEstValide() ? "default" : "destructive"}>
                            {user.getEstValide() ? "Actif" : "Inactif"}
                          </Badge>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="applications">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {applications.map((app) => (
                <Card key={app.getIdApplication()}>
                  <CardHeader>
                    <CardTitle>{app.getNomApplication()}</CardTitle>
                    <CardDescription>Version {app.getVersion()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        <strong>ID:</strong> {app.getIdApplication()}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Chemin:</strong> {app.getCheminInstallation()}
                      </p>
                      <div className="flex gap-2 mt-4">
                        <Button size="sm" variant="outline" onClick={() => serveur.desinstallerApplicationServeur(app)}>
                          Désinstaller
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="requests">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Demandes de Quota</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {demandesQuota.map((demande, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{demande.getDemandeur().getNom()}</h3>
                          <p className="text-sm text-gray-600">{demande.getRaison()}</p>
                          <p className="text-sm font-medium">
                            Augmentation demandée: {formatBytes(demande.getAugmentationDemandee())}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => traiterDemandeQuota(demande, true)}>
                            Approuver
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => traiterDemandeQuota(demande, false)}>
                            Refuser
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Demandes d'Installation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {demandesInstallation.map((demande, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-medium">{demande.getDemandeur().getNom()}</h3>
                          <p className="text-sm text-gray-600">{demande.getRaison()}</p>
                          <p className="text-sm font-medium">
                            {demande.getNomApplicationDemandee()} v{demande.getVersionDemandee()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => traiterDemandeInstallation(demande, true)}>
                            Approuver
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => traiterDemandeInstallation(demande, false)}
                          >
                            Refuser
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sessions">
            <Card>
              <CardHeader>
                <CardTitle>Sessions Actives</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sessions.map((session) => (
                    <div
                      key={session.getIdSession()}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div>
                        <h3 className="font-medium">{session.getCompteUtilisateur().getNomUtilisateur()}</h3>
                        <p className="text-sm text-gray-600">Session ID: {session.getIdSession()}</p>
                        <p className="text-sm text-gray-600">Ouverture: {session.getDateDebut().toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">IP: {session.getIpConnectee()}</p>
                        <p className="text-sm text-gray-600">MAC: {session.getMacConnectee()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notif, index) => (
                    <div key={index} className="flex items-start gap-3 p-4 border rounded-lg">
                      {getNotificationIcon(notif.getType())}
                      <div className="flex-1">
                        <p className="font-medium">{notif.getMessage()}</p>
                        <p className="text-sm text-gray-600">{notif.getDateEnvoi().toLocaleString()}</p>
                        <Badge variant="outline" className="mt-2">
                          {notif.getType()}
                        </Badge>
                      </div>
                      <div className="text-right">
                        <Badge variant={notif.getEstLue() ? "default" : "destructive"}>
                          {notif.getEstLue() ? "Lu" : "Non lu"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
