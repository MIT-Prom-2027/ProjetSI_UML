import { Utilisateur } from "../Utilisateur"
import { Administrateur } from "../Administrateur"
import { UtilisateurStandard } from "../UtilisateurStandard"
import { Application } from "../Application"
import { EspaceStockage } from "../Espace_stockage"
import { Fichier } from "../Fichier"
import { DemandeQuota } from "../DemandeQuota"
import { DemandeInstallation } from "../DemandeInstallation"
import { Session } from "../Session"
import { Notification, TypeNotification } from "../Notification"
import { PermissionType } from "../Administrateur"

// Comptes système NIS/NFS (Utilisateur) - Comptes Unix du serveur
export const comptesSystemeFictifs: Utilisateur[] = [
  (() => {
    const user = new Utilisateur("jdupont_sys")
    user.setIdCompte(1001) // UID système Unix
    user.setEstValidite(true)
    user.setQuotaMaxGo(5000000) // 5GB en bytes
    user.setEspaceUtilisee(2500000) // 2.5GB utilisé
    user.setMotDepasseHash("$6$salt$hash123") // Hash Unix
    return user
  })(),
  (() => {
    const user = new Utilisateur("mmartin_sys")
    user.setIdCompte(1002)
    user.setEstValidite(true)
    user.setQuotaMaxGo(3000000) // 3GB
    user.setEspaceUtilisee(1800000) // 1.8GB utilisé
    user.setMotDepasseHash("$6$salt$hash456")
    return user
  })(),
  (() => {
    const user = new Utilisateur("pbernard_sys")
    user.setIdCompte(1003)
    user.setEstValidite(false)
    user.setQuotaMaxGo(2000000) // 2GB
    user.setEspaceUtilisee(500000) // 0.5GB utilisé
    user.setMotDepasseHash("$6$salt$hash789")
    return user
  })(),
]

// Utilisateurs web (UtilisateurSite) - Administrateurs du site web
export const administrateursWebFictifs: Administrateur[] = [
  (() => {
    const admin = new Administrateur("Dupont", "Jean", "jean.dupont@example.com")
    admin.setIdPersonne(1)
    // Lié au compte système NIS/NFS jdupont_sys
    admin.getCompteSysteme().setIdCompte(1001)
    admin.getCompteSysteme().setNomUtilisateur("jdupont_sys")
    admin.getCompteSysteme().setEstValidite(true)
    admin.getCompteSysteme().setQuotaMaxGo(5000000)
    admin.getCompteSysteme().setEspaceUtilisee(2500000)
    return admin
  })(),
  (() => {
    const admin = new Administrateur("Admin", "Super", "admin@example.com")
    admin.setIdPersonne(2)
    // Compte système dédié admin
    admin.getCompteSysteme().setIdCompte(1000)
    admin.getCompteSysteme().setNomUtilisateur("admin_sys")
    admin.getCompteSysteme().setEstValidite(true)
    admin.getCompteSysteme().setQuotaMaxGo(10000000)
    admin.getCompteSysteme().setEspaceUtilisee(1000000)
    return admin
  })(),
]

// Utilisateurs web standards (UtilisateurSite) - Clients du site web
export const utilisateursWebFictifs: UtilisateurStandard[] = [
  (() => {
    const user = new UtilisateurStandard("Martin", "Marie", "marie.martin@example.com")
    user.setIdPersonne(3)
    // Lié au compte système NIS/NFS mmartin_sys
    user.getCompteSysteme().setIdCompte(1002)
    user.getCompteSysteme().setNomUtilisateur("mmartin_sys")
    user.getCompteSysteme().setEstValidite(true)
    user.getCompteSysteme().setQuotaMaxGo(3000000)
    user.getCompteSysteme().setEspaceUtilisee(1800000)
    return user
  })(),
  (() => {
    const user = new UtilisateurStandard("Bernard", "Pierre", "pierre.bernard@example.com")
    user.setIdPersonne(4)
    // Lié au compte système NIS/NFS pbernard_sys
    user.getCompteSysteme().setIdCompte(1003)
    user.getCompteSysteme().setNomUtilisateur("pbernard_sys")
    user.getCompteSysteme().setEstValidite(false)
    user.getCompteSysteme().setQuotaMaxGo(2000000)
    user.getCompteSysteme().setEspaceUtilisee(500000)
    return user
  })(),
]

// Applications système installées sur le serveur
export const applicationsFictives: Application[] = [
  (() => {
    const app = new Application(1, "Apache HTTP Server", "2.4.57")
    app.setCheminInstallation("/usr/sbin/httpd")
    return app
  })(),
  (() => {
    const app = new Application(2, "MySQL Server", "8.0.35")
    app.setCheminInstallation("/usr/sbin/mysqld")
    return app
  })(),
  (() => {
    const app = new Application(3, "PHP", "8.2.12")
    app.setCheminInstallation("/usr/bin/php")
    return app
  })(),
  (() => {
    const app = new Application(4, "Samba", "4.18.6")
    app.setCheminInstallation("/usr/sbin/smbd")
    return app
  })(),
]

// Espaces de stockage NFS liés aux comptes système
export const espacesStockageFictifs: EspaceStockage[] = [
  new EspaceStockage(comptesSystemeFictifs[0], "/home/jdupont_sys", [PermissionType.LIRE, PermissionType.ECRIRE]),
  new EspaceStockage(comptesSystemeFictifs[1], "/home/mmartin_sys", [
    PermissionType.LIRE,
    PermissionType.ECRIRE,
    PermissionType.EXECUTER,
  ]),
  new EspaceStockage(comptesSystemeFictifs[2], "/home/pbernard_sys", [PermissionType.LIRE]),
  // Espaces partagés
  new EspaceStockage(comptesSystemeFictifs[0], "/shared/projects", [
    PermissionType.LIRE,
    PermissionType.ECRIRE,
    PermissionType.EXECUTER,
  ]),
]

// Fichiers dans les espaces NFS
export const fichiersFictifs: Fichier[] = [
  new Fichier(1, "rapport_mensuel.pdf", espacesStockageFictifs[0]),
  new Fichier(2, "projet_web.tar.gz", espacesStockageFictifs[0]),
  new Fichier(3, "photo_profil.jpg", espacesStockageFictifs[1]),
  new Fichier(4, "backup_script.sh", espacesStockageFictifs[1]),
  new Fichier(5, "documentation.txt", espacesStockageFictifs[2]),
  new Fichier(6, "shared_config.conf", espacesStockageFictifs[3]),
]

// Demandes de quota faites via le site web
export const demandesQuotaFictives: DemandeQuota[] = [
  new DemandeQuota(2000000, utilisateursWebFictifs[0], "Besoin d'espace pour projet de développement web"),
  new DemandeQuota(1000000, utilisateursWebFictifs[1], "Stockage de données de recherche scientifique"),
]

// Demandes d'installation faites via le site web
export const demandesInstallationFictives: DemandeInstallation[] = [
  new DemandeInstallation(utilisateursWebFictifs[0], "Développement Python", "Python", "3.11"),
  new DemandeInstallation(administrateursWebFictifs[0], "Analyse de données", "R", "4.3.0"),
]

// Sessions système NIS/NFS (connexions Unix)
export const sessionsFictives: Session[] = [
  (() => {
    const session = new Session(comptesSystemeFictifs[0])
    session.setIdSession(1)
    session.setIpConnectee("192.168.1.100")
    session.setMacConnectee("00:1B:44:11:3A:B7")
    return session
  })(),
  (() => {
    const session = new Session(comptesSystemeFictifs[1])
    session.setIdSession(2)
    session.setIpConnectee("192.168.1.101")
    session.setMacConnectee("00:1B:44:11:3A:B8")
    return session
  })(),
]

// Notifications envoyées aux utilisateurs web
export const notificationsFictives: Notification[] = [
  (() => {
    const notif = new Notification(3, "Votre quota système est à 85% de sa capacité")
    notif.setType(TypeNotification.AVERTISSEMENT)
    return notif
  })(),
  (() => {
    const notif = new Notification(4, "Nouvelle application Python installée sur le serveur")
    notif.setType(TypeNotification.SUCCES)
    return notif
  })(),
  (() => {
    const notif = new Notification(3, "Erreur lors de la sauvegarde automatique")
    notif.setType(TypeNotification.ERREUR)
    return notif
  })(),
  (() => {
    const notif = new Notification(1, "Maintenance programmée ce weekend")
    notif.setType(TypeNotification.INFO)
    return notif
  })(),
]

// Export des données pour l'interface
export const utilisateursFictifs = comptesSystemeFictifs // Comptes système NIS/NFS
export const administrateursFictifs = administrateursWebFictifs // Admins du site web
